package com.media.dto;

import lombok.Data;

@Data
public class CmemberDto {
	private String cid;
	private String pw;
	private String cnum;
	private String email;
	private String address;
	private String cname;
	private String phone;
	private String ceo;
	
	
	
}