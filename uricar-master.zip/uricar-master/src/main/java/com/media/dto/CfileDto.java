package com.media.dto;

import lombok.Data;

@Data
public class CfileDto {
	private String cf_oriName;
	private String cf_sysName;
	private String cp_oriName;
	private String cp_sysName;
	
}
